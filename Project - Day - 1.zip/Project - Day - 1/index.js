const express = require('express');
const app = express();
const path = require('path');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

let students = [
  { id: 1, name: 'John Doe' },
  { id: 2, name: 'Jane Doe' },
];

app.get('/', (req, res) => {
  res.render('index', { student: students });
});

app.post('/insertData', (req, res) => {
  res.redirect('/');
});

app.get('/deleteData', (req, res) => {
  res.redirect('/');
});

app.get('/editData', (req, res) => {
  res.redirect('/');
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
